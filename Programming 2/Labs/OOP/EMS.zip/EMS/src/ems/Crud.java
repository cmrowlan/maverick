/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ems;

/**
 *
 * @author Chase
 */
public class Crud {
    //f
    Db db = new Db();
    
    //m
    public String register(Employee emp){
        String result = db.register(emp);
        return result;
    }//reg
    
    public String search(String ID){
        String result = db.search(ID);
        return result;
    }//search
    
    public int numEmployees(){
        int result = db.numEmployees();
        return result;
    }//numEmp
    
    public String listEmployees(){
        String result = db.listEmployees();
        return result;
    }
    //c
}//class
