/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ems;
import java.util.*;

/**
 *
 * @author Chase
 */
public class Ui {
    //f
    Scanner sc = new Scanner(System.in);
    Scanner sc1 = new Scanner(System.in);
    Scanner sc2 = new Scanner(System.in);
    int status = 0;
    //m
    
    
   //switch case here for 1-5
    //menu
    
    
    public void showMenu(){
        do{
        System.out.println("Menu---------------");
        System.out.println("1 - Register Employee");
        System.out.println("2 - Search Employee");
        System.out.println("3 - Number of Employees Registered");
        System.out.println("4 - List All Employees");
        System.out.println("5 - Quit Program");
        System.out.println("-------------------");
        System.out.println("Please select an option from above: ");
        String option = sc.nextLine();
         switch(option){
            case "1" : //register
                System.out.println("REGISTRATION------");
                System.out.print("enter id: ");
                int id = sc.nextInt();
                System.out.print("enter name: ");
                String name = sc1.nextLine();
                System.out.println("enter DOB (mm/dd/yy) : ");
                String DOB = sc2.nextLine();
                Employee emp = new Employee(id, name, DOB);
                Crud cr = new Crud();
                cr.register(emp);
                System.out.println("User was successfully registered!");
                break;
            case "2" : //search
                System.out.println("SEARCH BY ID-------------");
                System.out.println("Enter ID (2 Digits): ");
                String id2 = sc.next();
                Crud cr2 = new Crud();
                String result2 = cr2.search(id2);
                System.out.println(result2);
                break;
            case "3" : //numEmp
                Crud cr3 = new Crud();
                System.out.println("Total number of employees: " + cr3.numEmployees());
                break;
            case "4" : //listEmp
                Crud cr4 = new Crud();
                System.out.println("Employee List: ");
                System.out.println(cr4.listEmployees());
                break;
            case "5" : //quit
                status = 6;
                System.exit(0);
                
        }
        
            
        } while(status < 5);
        
    }
}
    //op 1 - Register
   /* public void showReg(){
        System.out.println("REGISTRSTION------");
        System.out.print("enter id: ");
        int id = sc.nextInt();
        System.out.print("enter name: ");
        String name = sc1.nextLine();
        System.out.println("enter DOB (mm/dd/yy) : ");
        String DOB = sc2.nextLine();
        Employee emp = new Employee(id, name, DOB);
        Crud cr = new Crud();
        Employee result = cr.register(emp);
        System.out.println(result.getName() + " was successfully registered!");
    }//showR
    //op 2 - Search
    public void searchID(){
        System.out.println("SEARCH BY ID-------------");
        System.out.println("Enter ID (2 Digits): ");
        String id = sc.next();
        Crud cr = new Crud();
        String result = cr.search(id);
        System.out.println(result);
    }
    
    //op 3 - Number of Employees registered
    public void numEmployees(){
        Crud cr = new Crud();
        System.out.println("Total number of employees: " + cr.numEmployees());
    }
    
    public void listEmployees(){
        Crud cr = new Crud();
        System.out.println("Employee List: ");
        System.out.println(cr.listEmployees());
        
    }
    public void quit(){
        this.status = true;
        System.exit(0);
    }
}//c*/

