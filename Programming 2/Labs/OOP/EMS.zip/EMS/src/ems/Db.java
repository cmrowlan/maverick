/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ems;

import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author Chase
 */
public class Db {
    int counter;
    //f
    ArrayList <Employee> list = new ArrayList <> ();
    int db1 = 0;
    
    //m
    public String register(Employee emp){
        
        list.add(emp.toString());
        return "Registered";
        
    }//reg
    
    public String search(String ID){
        String employeeList[] = new String[10];
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < list.size(); i++) {
            stringBuilder.append(employeeList[i]);
        }
       for (int index = 0; index < employeeList.length; index++)
      {
           if ( employeeList[index].equals(ID) )
                 return employeeList[index];
      }

     return null;
}
    public int numEmployees(){
        int result = list.size();
        return result;
    }
    public String listEmployees(){
        StringBuilder sb = new StringBuilder();
        for (Employee e : list)
{
        sb.append(e);
        sb.append("\t");
}
        String result = sb.toString();
        return result;
    }       
    }
    
    //c

